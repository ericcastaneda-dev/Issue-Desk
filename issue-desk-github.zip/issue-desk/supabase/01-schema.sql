-- Issue Desk: database schema for Supabase (PostgreSQL)
-- Run this whole file once in the Supabase dashboard: SQL Editor -> New query -> paste -> Run.
--
-- What it creates
--   docs      one table holding every record (tickets, activity, reference tables, counters)
--   owners    emails that are always Admin and may edit Reference data (the "Editors")
--   profiles  display names of people who have signed in
--   leases    short locks used to hand out ticket numbers one at a time
-- and the rules that enforce, ON THE SERVER, who may read and change what:
--   Admin       everything
--   Helpdesk    raise tickets (created-by locked to their own email), comment
--   Technician  status / closing / actions done (closed-by locked to their own email,
--               actions done required to close), comment
--   Observer    read only
-- A person's role comes from the "Team members" reference table (matched on their
-- verified sign-in email). People who are not on that list, or have no role, can read nothing.

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------- tables
create table if not exists public.docs (
  path       text primary key,
  parent     text generated always as (regexp_replace(path, '/[^/]+$', '')) stored,
  data       jsonb       not null default '{}'::jsonb,
  version    bigint      not null default 1,
  updated_at timestamptz not null default now()
);
create index if not exists docs_parent_idx on public.docs (parent);

create table if not exists public.owners (
  email text primary key check (email = lower(email))
);

create table if not exists public.profiles (
  id         uuid primary key,
  email      text not null default '',
  name       text not null default '',
  updated_at timestamptz not null default now()
);

create table if not exists public.leases (
  path       text primary key,
  holder     text not null,
  expires_at timestamptz not null
);

alter table public.docs     enable row level security;
alter table public.owners   enable row level security;
alter table public.profiles enable row level security;
alter table public.leases   enable row level security;

-- ---------------------------------------------------------------- identity helpers
create or replace function public.jwt_email() returns text
language sql stable as $$
  select lower(btrim(coalesce(auth.jwt() ->> 'email', '')))
$$;

create or replace function public.is_owner() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.owners o where public.jwt_email() <> '' and o.email = public.jwt_email())
$$;

-- admin | helpdesk | technician | observer | null (no access)
create or replace function public.app_role() returns text
language plpgsql stable security definer set search_path = public as $$
declare r text;
begin
  if public.jwt_email() = '' then return null; end if;
  if public.is_owner() then return 'admin'; end if;
  select lower(btrim(m -> 'v' ->> 'role')) into r
    from public.docs d,
         jsonb_array_elements(case when jsonb_typeof(d.data -> 'rows') = 'array' then d.data -> 'rows' else '[]'::jsonb end) m
   where d.path = 'ref/team'
     and lower(btrim(coalesce(m -> 'v' ->> 'email', ''))) = public.jwt_email()
     and coalesce((m ->> 'active')::boolean, true)
   limit 1;
  if r in ('admin', 'helpdesk', 'technician', 'observer') then return r; end if;
  return null;
end $$;

create or replace function public.my_access() returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object('role', public.app_role(), 'owner', public.is_owner(),
                            'email', public.jwt_email(), 'uid', auth.uid())
$$;

-- ---------------------------------------------------------------- row guard (the real rules)
create or replace function public.docs_guard() returns trigger
language plpgsql security invoker set search_path = public as $$
declare
  r       text;
  owner   boolean;
  p       text;
  em      text;
  uid     text;
  o       jsonb;
  n       jsonb;
  changed text[];
  allowed text[];
begin
  -- the SQL editor / migrations / service key run as these roles and are trusted
  if current_user in ('postgres', 'service_role', 'supabase_admin') then
    if tg_op = 'DELETE' then return old; end if;
    if tg_op = 'UPDATE' then new.version := old.version + 1; end if;
    new.updated_at := now();
    return new;
  end if;

  p     := case when tg_op = 'DELETE' then old.path else new.path end;
  r     := public.app_role();
  owner := public.is_owner();
  em    := public.jwt_email();
  uid   := coalesce(auth.uid()::text, '');
  o     := case when tg_op = 'INSERT' then '{}'::jsonb else old.data end;
  n     := case when tg_op = 'DELETE' then '{}'::jsonb else new.data end;

  if r is null then raise exception 'not_allowed: no access' using errcode = '42501'; end if;
  if tg_op = 'UPDATE' and new.path <> old.path then
    raise exception 'not_allowed: path is fixed' using errcode = '42501';
  end if;

  -- each person's private area
  if p like 'data/users/%' then
    if split_part(p, '/', 3) <> uid then raise exception 'not_allowed: private area' using errcode = '42501'; end if;

  -- reference data: owners only
  elsif p = 'ref' or p like 'ref/%' then
    if not owner then raise exception 'not_allowed: reference data is edited by owners' using errcode = '42501'; end if;

  -- ticket number counter
  elsif p = 'meta/counter' then
    if r not in ('admin', 'helpdesk') then raise exception 'not_allowed: cannot raise tickets' using errcode = '42501'; end if;

  -- a ticket
  elsif p ~ '^tickets/[^/]+$' then
    if tg_op = 'INSERT' then
      if r not in ('admin', 'helpdesk') then raise exception 'not_allowed: your role cannot raise tickets' using errcode = '42501'; end if;
      if r = 'helpdesk' then
        if lower(coalesce(n -> 'createdBy' ->> 'email', '')) <> em then
          raise exception 'not_allowed: created-by email is locked to your sign-in' using errcode = '42501'; end if;
        if coalesce(n ->> 'reporter', '') <> uid then
          raise exception 'not_allowed: reporter must be you' using errcode = '42501'; end if;
        if jsonb_typeof(n -> 'closedAt') is not null and jsonb_typeof(n -> 'closedAt') <> 'null' then
          raise exception 'not_allowed: your role cannot close tickets' using errcode = '42501'; end if;
        if btrim(coalesce(n ->> 'actionsDone', '')) <> '' then
          raise exception 'not_allowed: your role cannot fill in actions done' using errcode = '42501'; end if;
      end if;
    elsif tg_op = 'DELETE' then
      if r <> 'admin' then raise exception 'not_allowed: only admins delete tickets' using errcode = '42501'; end if;
    else
      select coalesce(array_agg(k), '{}') into changed from (
        select k from jsonb_object_keys(o || n) k where (o -> k) is distinct from (n -> k)) s;
      if r = 'admin' then
        null;
      elsif r = 'technician' then
        allowed := array['status','closedAt','closedBy','actionsDone','updatedAt','lastEvent','lastBy'];
        if not (changed <@ allowed) then
          raise exception 'not_allowed: technicians can only change status, closing and actions done' using errcode = '42501'; end if;
        if n ->> 'status' = 'Closed' and btrim(coalesce(n ->> 'actionsDone', '')) = '' then
          raise exception 'not_allowed: actions done is required before closing' using errcode = '42501'; end if;
        if 'closedBy' in (select unnest(changed)) and jsonb_typeof(n -> 'closedBy') = 'object'
           and lower(coalesce(n -> 'closedBy' ->> 'email', '')) <> em then
          raise exception 'not_allowed: closed-by email is locked to your sign-in' using errcode = '42501'; end if;
      elsif r = 'helpdesk' then
        allowed := array['updatedAt','lastEvent','lastBy'];
        if not (changed <@ allowed) then
          raise exception 'not_allowed: your role can only comment on existing tickets' using errcode = '42501'; end if;
      else
        raise exception 'not_allowed: view only' using errcode = '42501';
      end if;
    end if;

  -- a ticket's activity log
  elsif p ~ '^tickets/[^/]+/activity/[^/]+$' then
    if tg_op = 'INSERT' then
      if r = 'observer' then raise exception 'not_allowed: view only' using errcode = '42501'; end if;
      if coalesce(n ->> 'by', '') <> uid then raise exception 'not_allowed: activity must be yours' using errcode = '42501'; end if;
    elsif r <> 'admin' then
      raise exception 'not_allowed: only admins change the activity log' using errcode = '42501';
    end if;

  -- anything else
  elsif r <> 'admin' then
    raise exception 'not_allowed' using errcode = '42501';
  end if;

  if tg_op = 'DELETE' then return old; end if;
  if tg_op = 'UPDATE' then new.version := old.version + 1; end if;
  new.updated_at := now();
  return new;
end $$;

drop trigger if exists docs_guard_trg on public.docs;
create trigger docs_guard_trg before insert or update or delete on public.docs
  for each row execute function public.docs_guard();

-- ---------------------------------------------------------------- row level security
drop policy if exists docs_read  on public.docs;
drop policy if exists docs_write  on public.docs;
drop policy if exists docs_insert on public.docs;
drop policy if exists docs_update on public.docs;
drop policy if exists docs_delete on public.docs;
create policy docs_read on public.docs for select to authenticated
  using ((select public.app_role()) is not null
         and (path not like 'data/users/%' or split_part(path, '/', 3) = coalesce(auth.uid()::text, '')));
create policy docs_insert on public.docs for insert to authenticated
  with check ((select public.app_role()) is not null);
create policy docs_update on public.docs for update to authenticated
  using ((select public.app_role()) is not null
         and (path not like 'data/users/%' or split_part(path, '/', 3) = coalesce(auth.uid()::text, '')))
  with check ((select public.app_role()) is not null);
create policy docs_delete on public.docs for delete to authenticated
  using ((select public.app_role()) is not null
         and (path not like 'data/users/%' or split_part(path, '/', 3) = coalesce(auth.uid()::text, '')));

drop policy if exists profiles_read  on public.profiles;
drop policy if exists profiles_write on public.profiles;
create policy profiles_read on public.profiles for select to authenticated
  using ((select public.app_role()) is not null);
create policy profiles_write on public.profiles for all to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

-- owners and leases are reached only through the functions in this file
revoke all on public.owners, public.leases from anon, authenticated;
revoke all on public.docs, public.profiles from anon;
grant select, insert, update, delete on public.docs     to authenticated;
grant select, insert, update, delete on public.profiles to authenticated;

-- ---------------------------------------------------------------- functions the page calls
create or replace function public.jsonb_deep_merge(a jsonb, b jsonb) returns jsonb
language plpgsql immutable as $$
declare k text; v jsonb; res jsonb := coalesce(a, '{}'::jsonb);
begin
  if jsonb_typeof(b) is distinct from 'object' then return b; end if;
  if jsonb_typeof(res) is distinct from 'object' then res := '{}'::jsonb; end if;
  for k, v in select * from jsonb_each(b) loop
    if v = '{"__delete__": true}'::jsonb then
      res := res - k;
    elsif jsonb_typeof(v) = 'object' and jsonb_typeof(res -> k) = 'object' then
      res := jsonb_set(res, array[k], public.jsonb_deep_merge(res -> k, v));
    else
      res := jsonb_set(res, array[k], v, true);
    end if;
  end loop;
  return res;
end $$;

-- merge fields into an existing document (nested objects merge, arrays are replaced)
create or replace function public.doc_update(p_path text, p_patch jsonb) returns void
language plpgsql security invoker set search_path = public as $$
declare n int;
begin
  update public.docs set data = public.jsonb_deep_merge(data, p_patch) where path = p_path;
  get diagnostics n = row_count;
  if n = 0 then raise exception 'not_found: %', p_path using errcode = 'P0002'; end if;
end $$;

-- hand out a short lock so two people never get the same ticket number
create or replace function public.doc_acquire(p_path text, p_holder text, p_ttl_ms int) returns boolean
language plpgsql security definer set search_path = public as $$
declare ok boolean;
begin
  if public.app_role() not in ('admin', 'helpdesk') then return false; end if;
  insert into public.leases as l (path, holder, expires_at)
       values (p_path, p_holder, now() + make_interval(secs => greatest(p_ttl_ms, 100) / 1000.0))
  on conflict (path) do update set holder = excluded.holder, expires_at = excluded.expires_at
       where l.expires_at < now() or l.holder = excluded.holder
  returning true into ok;
  return coalesce(ok, false);
end $$;

-- record who is signed in so names can be shown on tickets and activity
create or replace function public.touch_profile(p_name text) returns void
language plpgsql security invoker set search_path = public as $$
begin
  if auth.uid() is null then return; end if;
  insert into public.profiles (id, email, name, updated_at)
       values (auth.uid(), public.jwt_email(), left(coalesce(p_name, ''), 120), now())
  on conflict (id) do update set email = excluded.email, name = excluded.name, updated_at = now();
end $$;

revoke all on function public.my_access(), public.doc_update(text, jsonb), public.doc_acquire(text, text, int),
  public.touch_profile(text) from public, anon;
grant execute on function public.my_access(), public.doc_update(text, jsonb), public.doc_acquire(text, text, int),
  public.touch_profile(text) to authenticated;
grant execute on function public.app_role(), public.is_owner(), public.jwt_email(), public.jsonb_deep_merge(jsonb, jsonb) to authenticated;

-- ---------------------------------------------------------------- live updates
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime')
     and not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'docs') then
    alter publication supabase_realtime add table public.docs;
  end if;
end $$;
