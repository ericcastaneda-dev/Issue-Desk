# Issue Desk – self-hosted (Supabase + your own domain)

What you get: a static web page (`web/`) plus a Supabase database with email sign-in.
Roles (Admin / Helpdesk / Technician / Observer) are enforced **in the database**, not just on the page.

## Files
- `web/index.html`, `web/config.js` – the site. Only `config.js` needs editing.
- `supabase/01-schema.sql` – tables, security rules, functions.
- `supabase/02-seed-reference.sql` – your owner account, categories, team and roles, site table definition.
- `supabase/03-seed-sites-1…6.sql` – the 4,798 site rows.

## 1. Create the Supabase project (about 10 min)
1. Sign up at supabase.com, **New project**, choose a region near you, save the database password.
2. **SQL Editor → New query**: paste `01-schema.sql`, Run. Then `02-seed-reference.sql`, Run. Then each `03-seed-sites-N.sql`, Run (each once; re-running is safe).
   - `02` makes **eric.castaneda@comclark.com.ph** the owner. Owners are always Admin and are the only people who can edit Reference data. To add another owner later: `insert into owners(email) values ('name@company.com');`
   - Team members and roles are then managed in the app under Reference data → Team members.
3. **Project Settings → API**: copy the Project URL and the `anon` public key into `web/config.js`.

## 2. Email sign-in
Users sign in with a code (or link) sent to their email. In **Authentication**:
- **Providers → Email**: enabled. Keep “Confirm email” on.
- **Email Templates → Magic Link**: include the code so people can type it, e.g. add `Your sign-in code: {{ .Token }}` to the body. (`{{ .ConfirmationURL }}` is the one-click link.) Do the same for **Confirm signup**, because first-time users get that template.
- **URL Configuration**: set **Site URL** to your site address (e.g. `https://helpdesk.yourdomain.com`) and add it under **Redirect URLs**.
- **SMTP (important)**: Supabase’s built-in sender is limited to a few emails per hour and only meant for testing. Under **Project Settings → Authentication → SMTP**, enter your own mail server (your company mail, Microsoft 365, SendGrid, etc.).
- Anyone can request a code, but unless their email is on the Team list (or is an owner) they see “You don’t have access” and the database returns nothing to them.

## 3. Put the site online
Upload the `web` folder contents to any static host: Cloudflare Pages, Netlify, GitHub Pages, Vercel, or your own web server. Point your domain/subdomain at it (host’s “custom domain” setting), HTTPS on. No build step.

## 4. First run
Open the site, enter your email, type the code. You should see Dashboard, Executive, Tickets and Reference data. Check Reference data → Team members, add your people with their roles.

## Notes
- Ticket numbers (E-LEARN-000#) are issued by the database with a short lock, so two people raising tickets at once get different numbers.
- Observer “Notify on new tickets”: observers see an in-app alert; the raiser gets the one-click email button. Sending email automatically needs an extra service (a Supabase Edge Function + SMTP) which is not included.
- Realtime: updates appear live. If a laptop sleeps, data refreshes when the tab is opened again.
- Backups: Supabase Pro has daily backups; on the free plan export from time to time (Database → Backups, or `pg_dump`). Free projects pause after a week of no use.
- Tickets from the claude.ai version are not copied; only reference data is.

## Hosting on GitHub Pages
1. Create a GitHub repository and push this folder to its `main` branch.
2. Repository **Settings → Pages → Source: GitHub Actions**. The included workflow publishes `index.html` and `config.js` on every push (the SQL files are not published).
3. Your site appears at `https://<user>.github.io/<repo>/`. For your own domain, add it under Settings → Pages → Custom domain and create the DNS record GitHub shows.
4. In Supabase → Authentication → URL Configuration, set the Site URL and Redirect URLs to that address.
Use a **private** repo if you prefer: `config.js` holds only the public anon key, but the repo also contains your team list in `02-seed-reference.sql`.
Note: GitHub Pages on private repos needs a paid GitHub plan.
